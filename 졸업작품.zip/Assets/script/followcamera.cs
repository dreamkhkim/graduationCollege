﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class followcamera : MonoBehaviour
{

    public Transform target; // 카메라 타켓
    public float smoothspeed = 0.125f; // 타켓팅 따라다는 카메라 속도
    public Vector3 offset; // 카메라 위치 값

	// Use this for initialization
	void Start ()
    {
		
	}

    private void LateUpdate()
    {
        Vector3 desiredposition = target.position + offset; // 타켓 잡은 지점에서 위치값을 더해준다.
        Vector3 smoothedposition = Vector3.Lerp(transform.position, desiredposition, smoothspeed); // 타켓을 따라간다.
        // 현재위치 값을 smoothedposion에서 따라가준다.
        transform.position = smoothedposition;
    }

    // Update is called once per frame
    void Update () {
		
	}
}
